SELECT network_name, security_type, mode, channel, rssi, interface FROM wifi_status;
