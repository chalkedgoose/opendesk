SELECT * from system_info;
