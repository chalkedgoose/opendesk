 SELECT network_name, last_connected, security_type, captive_portal FROM wifi_networks;
