 SELECT days, hours, minutes, seconds, total_seconds FROM uptime;
