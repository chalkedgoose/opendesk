SELECT key, name, celsius, fahrenheit FROM temperature_sensors;
